<?php
include 'index.php';
var_dump(checkYahoo('hunetr10092@yahoo.com'));